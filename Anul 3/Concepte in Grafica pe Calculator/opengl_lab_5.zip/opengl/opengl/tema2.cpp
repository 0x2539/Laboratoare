// Codul sursa este adaptat dupa OpenGLBook.com

#include <windows.h>  // biblioteci care urmeaza sa fie incluse
#include <stdlib.h> // necesare pentru citirea shader-elor
#include <stdio.h>
#include <GL/glew.h> // glew apare inainte de freeglut
#include <GL/freeglut.h> // nu trebuie uitat freeglut.h
#include <fstream>
#include <iostream>
#include <vector>
#include <string>
using namespace std;
//////////////////////////////////////

GLuint
VaoId,
VboId,
ColorBufferId,
VertexShaderId,
FragmentShaderId,
ProgramId;


struct Punct
{
    float x;
    float y;
    bool operator==(Punct a)
    {
        return (x == a.x&&y == a.y);
    }
};
struct Linie
{
    Punct a;
    Punct b;
    float R;
    float G;
    float B;
    Linie()
    {
        R=1.0f;
        G=1.0f;
        B=1.0f;
    }
    bool operator==(Linie otherLine)
    {
        return (a == otherLine.a&&b == otherLine.b);
    }
};
//C fata de [AB]
float Parte(Punct a, Punct b, Punct c)
{
    //(x-x1)/(x2-x1)=(y-y1)/(y2-y1)
    //(x-x1)(y2-y1)-(y-y1)(x2-x1)=0
    return (c.x - a.x)*(b.y - a.y) - (c.y - a.y)*(b.x - a.x);
}
char get_line_intersection(float p0_x, float p0_y, float p1_x, float p1_y,
    float p2_x, float p2_y, float p3_x, float p3_y, float *i_x, float *i_y)
{
    float s1_x, s1_y, s2_x, s2_y;
    s1_x = p1_x - p0_x;     s1_y = p1_y - p0_y;
    s2_x = p3_x - p2_x;     s2_y = p3_y - p2_y;

    float s, t;
    s = (-s1_y * (p0_x - p2_x) + s1_x * (p0_y - p2_y)) / (-s2_x * s1_y + s1_x * s2_y);
    t = ( s2_x * (p0_y - p2_y) - s2_y * (p0_x - p2_x)) / (-s2_x * s1_y + s1_x * s2_y);

    if (s >= 0 && s <= 1 && t >= 0 && t <= 1)
    {
        // Collision detected
        if (i_x != NULL)
            *i_x = p0_x + (t * s1_x);
        if (i_y != NULL)
            *i_y = p0_y + (t * s1_y);
        return 1;
    }

    return 0; // No collision
}
//dreapta [AB] fata de [CD]
bool Intersect(Punct a, Punct b, Punct c, Punct d, Punct &e)
{
    if (a == c || b == c || a == d || c == d)
        return false;
    float rezC = Parte(a, b, c);
    float rezD = Parte(a, b, d);
    float rez2A = Parte(c, d, a);
    float rez2B = Parte(c, d, b);
    float rez = rezC*rezD;
    float rez2 = rez2A*rez2B;
    if (rez<0 && rez2<0)
    {
        get_line_intersection(a.x,a.y,b.x,b.y,c.x,c.y,d.x,d.y,&e.x,&e.y);
        return true;
    }
    else
        return false;
}

bool Intersect(Linie a, Linie b, Punct &e)
{
    return Intersect(a.a, a.b, b.a, b.b, e);
}

std::string readFile(const char *filePath) {
    std::string content;
    std::ifstream fileStream(filePath, std::ios::in);

    if (!fileStream.is_open()) {
        std::cerr << "Could not read file " << filePath << ". File does not exist." << std::endl;
        return "";
    }

    std::string line = "";
    while (!fileStream.eof()) {
        std::getline(fileStream, line);
        content.append(line + "\n");
    }

    fileStream.close();
    return content;
}

///////////////////////////////////////////
GLuint LoadShader(char* path, GLenum shaderType)
{
    string file = readFile(path);
    if (file != "")
    {
        const char *shader = file.c_str();
        GLuint shaderID = glCreateShader(shaderType);
        glShaderSource(shaderID, 1, &shader, NULL);
        glCompileShader(shaderID);
        cout << "Successfuly loaded " << path << "\n";
        return shaderID;
    }
    cout << "Failed loading " << path << "\n";
    return -1;
}
void CreateVBO(GLfloat *vertices,size_t verticesNo, GLfloat *colors, size_t colorsNo)
{
    glGenBuffers(1, &VboId);
    // este setat ca buffer curent
    glBindBuffer(GL_ARRAY_BUFFER, VboId);
    // punctele sunt "copiate" in bufferul curent
    glBufferData(GL_ARRAY_BUFFER, sizeof(GLfloat)*verticesNo, vertices, GL_STATIC_DRAW);

    // se creeaza / se leaga un VAO (Vertex Array Object) - util cand se utilizeaza mai multe VBO
    glGenVertexArrays(1, &VaoId);
    glBindVertexArray(VaoId);
    // se activeaza lucrul cu atribute; atributul 0 = pozitie
    glEnableVertexAttribArray(0);
    //
    glVertexAttribPointer(0, 4, GL_FLOAT, GL_FALSE, 0, 0);

    // un nou buffer, pentru culoare
    glGenBuffers(1, &ColorBufferId);
    glBindBuffer(GL_ARRAY_BUFFER, ColorBufferId);
    glBufferData(GL_ARRAY_BUFFER, sizeof(GLfloat)*colorsNo, colors, GL_STATIC_DRAW);
    // atributul 1 =  culoare
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(1, 4, GL_FLOAT, GL_FALSE, 0, 0);

    GLfloat matrix[] = {
        1.0f,0.0f,0.0f,0.0f,
        0.0f,1.0f,0.0f,0.0f,
        0.0f,0.0f,1.0f,0.0f,
        0.0f,0.0f,0.0f,1.0f
    };
    GLuint matrixBufferId;

    matrixBufferId=glGetUniformLocation(ProgramId,"matrix");
    glUniformMatrix4fv(matrixBufferId,1,GL_FALSE,matrix);

    /*
    glGenBuffers(1, &matrixBufferId);
    glBindBuffer(GL_ARRAY_BUFFER, matrixBufferId);
    glBufferData(GL_ARRAY_BUFFER, sizeof(GLfloat)*4, matrix, GL_STATIC_DRAW);
    glEnableVertexAttribArray(2);
    glVertexAttribPointer(2, 4, GL_FLOAT, GL_FALSE, 0, 0);
    */

}
void CreateVBO(void)
{
    // varfurile
    GLfloat Vertices[] = {
        -0.8f, -0.8f, 0.0f, 1.0f,
        0.0f,  0.8f, 0.0f, 1.0f,
        0.8f, -0.8f, 0.0f, 1.0f
    };

    // culorile, ca atribute ale varfurilor
    GLfloat Colors[] = {
        1.0f, 0.0f, 1.0f, 1.0f,
        0.0f, 1.0f, 0.0f, 1.0f,
        0.0f, 0.0f, 1.0f, 1.0f
    };


    // se creeaza un buffer nou
    glGenBuffers(1, &VboId);
    // este setat ca buffer curent
    glBindBuffer(GL_ARRAY_BUFFER, VboId);
    // punctele sunt "copiate" in bufferul curent
    glBufferData(GL_ARRAY_BUFFER, sizeof(Vertices), Vertices, GL_STATIC_DRAW);

    // se creeaza / se leaga un VAO (Vertex Array Object) - util cand se utilizeaza mai multe VBO
    glGenVertexArrays(1, &VaoId);
    glBindVertexArray(VaoId);
    // se activeaza lucrul cu atribute; atributul 0 = pozitie
    glEnableVertexAttribArray(0);
    //
    glVertexAttribPointer(0, 4, GL_FLOAT, GL_FALSE, 0, 0);

    // un nou buffer, pentru culoare
    glGenBuffers(1, &ColorBufferId);
    glBindBuffer(GL_ARRAY_BUFFER, ColorBufferId);
    glBufferData(GL_ARRAY_BUFFER, sizeof(Colors), Colors, GL_STATIC_DRAW);
    // atributul 1 =  culoare
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 0, 0);
}

void DestroyVBO(void)
{
    glDisableVertexAttribArray(1);
    glDisableVertexAttribArray(0);

    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glDeleteBuffers(1, &ColorBufferId);
    glDeleteBuffers(1, &VboId);

    glBindVertexArray(0);
    glDeleteVertexArrays(1, &VaoId);
}

void CreateShaders(void)
{

    /*VertexShaderId = glCreateShader(GL_VERTEX_SHADER);
    glShaderSource(VertexShaderId, 1, &VertexShader, NULL);
    glCompileShader(VertexShaderId);*/

    VertexShaderId = LoadShader("Shaders\\vertex_shader.glsl", GL_VERTEX_SHADER);

    //FragmentShaderId = glCreateShader(GL_FRAGMENT_SHADER);
    //glShaderSource(FragmentShaderId, 1, &FragmentShader, NULL);
    //glCompileShader(FragmentShaderId);

    FragmentShaderId = LoadShader("Shaders\\fragment_shader.glsl", GL_FRAGMENT_SHADER);


    ProgramId = glCreateProgram();
    glAttachShader(ProgramId, VertexShaderId);
    glAttachShader(ProgramId, FragmentShaderId);
    glLinkProgram(ProgramId);
    glUseProgram(ProgramId);

}

void DestroyShaders(void)
{

    glUseProgram(0);

    glDetachShader(ProgramId, VertexShaderId);
    glDetachShader(ProgramId, FragmentShaderId);

    glDeleteShader(FragmentShaderId);
    glDeleteShader(VertexShaderId);

    glDeleteProgram(ProgramId);

}
Linie *linii;
Punct *puncte;
vector<Punct> punctemulte;
vector<Punct> intersectii;
int nrPuncte;
int nrIntersectii;
float f=0;

void magieCuPuncte()
{
	int fisier=0;
    if(fisier)
	{
		ifstream f("Puncte.txt");
		f >> nrPuncte;
		nrIntersectii=0;
		puncte = new Punct[nrPuncte + 1];
		for (int i = 0; i<nrPuncte; i++)
		{
			Punct p;
			f >> p.x;
			f >> p.y;
			puncte[i] = p;
		}
	}
	else{
		nrIntersectii=0;
		nrPuncte=punctemulte.size();
		//cout<<"Dimensiune punctemulte (render) ("<<nrPuncte<<")\n";
		puncte=new Punct[nrPuncte];
		intersectii.clear();
		for(int i=0;i<nrPuncte;i++)
		{
			puncte[i]=punctemulte.at(i);
		}
	}
    puncte[nrPuncte] = puncte[0];
    linii = new Linie[nrPuncte];
    for (int i = 0; i < nrPuncte; i++)
    {
        linii[i].a = puncte[i];
        linii[i].b = puncte[i + 1];
    }
    if(nrPuncte>2)
    {
        Punct intersectie;
        intersectie.x=0;
        intersectie.y=0;
        if (Intersect(linii[0], linii[nrPuncte],intersectie))
        {
            linii[0].R = 0;
            linii[nrPuncte].R = 0;
        }

        for (int i = 0; i < nrPuncte - 1; i++)
            for (int j = i + 1; j < nrPuncte ;j++)
            {
                Punct inters;
                inters.x=0;
                inters.y=0;
                if (Intersect(linii[i], linii[j], inters))
                {
                    linii[i].B = 0;
                    linii[j].B = 0;
                    intersectii.push_back(inters);
                    nrIntersectii++;
                }
            }
    }
}
void mouseceva(int x,int y,int z,int t)
{
    if(x==0&&y==1)
    {
		float width=800.0f;
		float height=600.0f;

		cout<<x<<" "<<y<<" "<<z<<" "<<t;
        Punct nou;
		nou.x=(z-width/2.0)/width;
		nou.y=-(t-height/2.0f)/height;
		nou.x*=2;
		nou.y*=2;

		cout<<" -> Punct:"<<nou.x<<" - "<<nou.y<<"\n";
        punctemulte.push_back(nou);
		cout<<"Dimensiune punctemulte (mouseceva) ("<<punctemulte.size()<<")\n";
    }
   
}
void Initialize(void)
{
    glClearColor(0.0f, 0.3f, 0.5f, 0.0f); // culoarea de fond a ecranului
    CreateShaders();
}

void RenderFunction(void)
{
    magieCuPuncte();
    glClear(GL_COLOR_BUFFER_BIT);
    /*CreateVBO();
    glPointSize(20.0);
    glDrawArrays(GL_TRIANGLES, 0, 3);*/
    f += 0.1f;
    glLineWidth(2);
    glPointSize(10);
    GLfloat *points = new GLfloat[nrPuncte * 4 * 2];
    for (int i = 0; i < nrPuncte; i++)
    {
        points[i * 8] = linii[i].a.x;
        points[i * 8 + 1] = linii[i].a.y;
        points[i * 8 + 2] = 0.0f;
        points[i * 8 + 3] = 1.0f;
        points[i * 8 + 4] = linii[i].b.x;
        points[i * 8 + 5] = linii[i].b.y;
        points[i * 8 + 6] = 0.0f;
        points[i * 8 + 7] = 1.0f;
    }
    GLfloat *colorPoints = new GLfloat[nrPuncte * 4 * 2];
    for (int i = 0; i < nrPuncte; i++)
    {
        colorPoints[i * 8] = linii[i].R;
        colorPoints[i * 8 + 1] = linii[i].G;
        colorPoints[i * 8 + 2] = linii[i].B;
        colorPoints[i * 8 + 3] = 1.0f;
        colorPoints[i * 8 + 4] = linii[i].R;
        colorPoints[i * 8 + 5] = linii[i].G;
        colorPoints[i * 8 + 6] = linii[i].B;
        colorPoints[i * 8 + 7] = 1.0f;
    }
    GLfloat Vertices[] = {
        -0.8f, -0.8f, 0.0f, 1.0f,
        0.0f,  0.8f, 0.0f, 1.0f,
        0.8f, -0.8f, 0.0f, 1.0f,
        0.8f, 0.8f, 0.0f, 1.0f
    };
    GLfloat Colors[] = {
        1.0f, 0.0f, 1.0f, 1.0f,
        0.0f, 1.0f, 0.0f, 1.0f,
        0.0f, 0.0f, 1.0f, 1.0f,
        1.0f, 1.0f, 1.0f, 1.0f
    };
    CreateVBO(points, nrPuncte*8, colorPoints, nrPuncte*8);

    glDrawArrays(GL_LINES, 0, nrPuncte*2);

   
    GLfloat *punctisoare;
    GLfloat *culori;
   
    punctisoare=new GLfloat[(nrPuncte+nrIntersectii)*4];
    culori=new GLfloat[(nrPuncte+nrIntersectii)*4];
    for(int i=0;i<nrPuncte;i++)
    {
        punctisoare[i * 4] = puncte[i].x;
        punctisoare[i * 4 + 1] = puncte[i].y;
        punctisoare[i * 4 + 2] = 0.0f;
        punctisoare[i * 4 + 3] = 1.0f;
        culori[i * 4] = 1.0f;
        culori[i * 4 + 1] = 1.0f;
        culori[i * 4 + 2] = 1.0f;
        culori[i * 4 + 3] = 1.0f;
    }
    for(int i=nrPuncte;i<nrPuncte+nrIntersectii;i++)
    {
        punctisoare[i * 4] = intersectii.at(i-nrPuncte).x;
        punctisoare[i * 4 + 1] = intersectii.at(i-nrPuncte).y;
        punctisoare[i * 4 + 2] = 0.0f;
        punctisoare[i * 4 + 3] = 1.0f;
        culori[i * 4] = 1.0f;
        culori[i * 4 + 1] = 0.0f;
        culori[i * 4 + 2] = 0.0f;
        culori[i * 4 + 3] = 1.0f;
    }
	
    CreateVBO(punctisoare, (nrPuncte+nrIntersectii)*4, culori, (nrPuncte+nrIntersectii)*4);
    glDrawArrays(GL_POINTS,0,nrPuncte+nrIntersectii);
    glFlush();
	DestroyVBO();
	glutPostRedisplay();

}
void Cleanup(void)
{
    DestroyShaders();
    DestroyVBO();
}

int main(int argc, char* argv[])
{
    ifstream f("Puncte.txt");
    f >> nrPuncte;
    nrIntersectii=0;
    puncte = new Punct[nrPuncte + 1];
    for (int i = 0; i<nrPuncte; i++)
    {
        Punct p;
        f >> p.x;
        f >> p.y;
        puncte[i] = p;
    }
    puncte[nrPuncte] = puncte[0];
    linii = new Linie[nrPuncte];
    for (int i = 0; i < nrPuncte; i++)
    {
        linii[i].a = puncte[i];
        linii[i].b = puncte[i + 1];
    }

    Punct intersectie;
    intersectie.x=0;
    intersectie.y=0;
    if (Intersect(linii[0], linii[nrPuncte],intersectie))
    {
        linii[0].R = 0;
        linii[nrPuncte].R = 0;
    }

    for (int i = 0; i < nrPuncte - 1; i++)
        for (int j = i + 1; j < nrPuncte ;j++)
        {
            Punct inters;
            inters.x=0;
            inters.y=0;
            if (Intersect(linii[i], linii[j], inters))
            {
                linii[i].B = 0;
                linii[j].B = 0;
                intersectii.push_back(inters);
                nrIntersectii++;
            }
        }
   

    //for (int i = 0; i<nrPuncte - 1; i++)
    //    for (int j = i + 1; j<nrPuncte; j++)
    //    {
    //        printf("Verific intre (%d,%d) si (%d,%d)\n", i, i + 1, j, j + 1);
    //        if (Intersect(puncte[i], puncte[i + 1], puncte[j], puncte[j + 1], intersectie))
    //        {
    //            //Schimba culoare, fa ceva aici
    //            printf("Intersectie intre (%d,%d) si (%d,%d)\n", i, i + 1, j, j + 1);
    //        }
    //    }

    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutInitWindowPosition(100, 100); // pozitia initiala a ferestrei
    glutInitWindowSize(800, 600); //dimensiunile ferestrei
    glutCreateWindow("Tema 2"); // titlul ferestrei
    glewInit(); // nu uitati de initializare glew; trebuie initializat inainte de a a initializa desenarea
    Initialize();
    glutDisplayFunc(RenderFunction);
    glutMouseFunc(mouseceva);
    glutCloseFunc(Cleanup);
    glutMainLoop();
}