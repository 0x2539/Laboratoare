3D-Camera-Movement
==================

Basic openGL 3D Camera Movement along a Chess Board terrain.
