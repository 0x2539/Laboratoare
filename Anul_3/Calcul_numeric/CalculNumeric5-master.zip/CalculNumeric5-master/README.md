CalculNumeric5
==============

Tema 5 Calcul Numeric

23 Apr 2014<br><t>- am urcat proiectul, sper sa il termin in maxim 3 zile.<br>
       - aproximarea integralei o voi afisa intr-un graf folosing JavaFX.
